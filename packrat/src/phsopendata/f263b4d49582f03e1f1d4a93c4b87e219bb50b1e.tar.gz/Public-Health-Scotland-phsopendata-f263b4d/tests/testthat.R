library(testthat)
library(phsopendata)

test_check("phsopendata")
